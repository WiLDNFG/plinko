var ScoreBin = function(id, low, medium, high, width, color, font,isJP) {
  this.id = id;
  this.low = low;
  this.medium = medium;
  this.high = high;
  this.width = width;
  this.color = color;
  this.font = font;
  this.isJP = isJP;
};
