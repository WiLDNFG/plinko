var customConfig = {
    app_id: 1267,
    redirect_uri: 'https://www.jackpotracer.com/dusty_plinko/',
    recaptcha_sitekey: '',
    //don't edit below this if you don't know what you're doing
    mp_api_uri: 'https://api.moneypot.com',
    mp_browser_uri: 'https://www.moneypot.com',
    chat_uri: 'https://socket.moneypot.com',
    brandName : 'Plinko',
    dropDev: false
};
